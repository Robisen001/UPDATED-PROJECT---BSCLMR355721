<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$FirstName = strip_tags($_POST['FirstName']);
$LastName = strip_tags($_POST['LastName']);
$MiddleName = strip_tags($_POST['MiddleName']);
$name = $FirstName." ".$LastName;

$DOB = strip_tags($_POST['DOB']);
$Citizenship = strip_tags($_POST['Citizenship']);
$country = strip_tags($_POST['country']);
$ID = strip_tags($_POST['ID']);
$YourGender = strip_tags($_POST['YourGender']);
$YearsOfEducationInEnglish = strip_tags($_POST['YearsOfEducationInEnglish']);
$OtherLangs = strip_tags($_POST['OtherLangs']);
$LevelOfEducation = strip_tags($_POST['LevelOfEducation']); 
$LevelEducation = strip_tags($_POST['LevelEducation']);
$SpecifyOthers = strip_tags($_POST['SpecifyOthers']);

$EducationLevel  = $LevelOfEducation||($SpecifyOthers && $LevelEducation);

$UploadPassport = strip_tags($_POST['UploadPassport']);
$Disability  = strip_tags($_POST['Disability']);
$ExplainDisability = strip_tags($_POST['ExplainDisability']);
$Religion = strip_tags($_POST['Religion']);
$SpecifyRelegion = strip_tags($_POST['SpecifyRelegion']);






$PA = strip_tags($_POST['PA']);
$PC  = strip_tags($_POST['PC']);
$Town = strip_tags($_POST['Town']);
$YouCountry = strip_tags($_POST['YouCountry']);
$Telephone = strip_tags($_POST['Telephone']);
$MobileNo = strip_tags($_POST['MobileNo']);
$Course = strip_tags($_POST['Course']);
$email = strip_tags($_POST['YourEmail']);










//validation
if(empty($FirstName)){
    header('location:index.php? error=FirstName');
    exit();
}

if(empty($LastName)){
    header('location:index.php? error=LastName');
    exit();
}

if(empty($email)){
    header('location:index.php? error=email');
    exit();
}

if(empty($inquiry)){
    header('location:index.php error=inquiry');
    exit();
}

if(empty($DOB)){
    header('location:index.php error=DOB');
    exit();
}

if (empty($MiddleName)){
    header('location:index.php error=MiddleName');
    exit();
}

if(empty($Citizenship)){
    header('location:index.php error=Citizenship');
    exit();
}

if(empty($country)){
    header('location:index.php error=country');
    exit();
}

if(empty($ID)){
    header('location:index.php error=ID');
    exit();
}

if(empty($YourGender)){
    header('location:index.php error=YourGender');
    exit();
}

if (empty($YearsOfEducationInEnglish)){
    header('location:index.php error=YearsOfEducationInEnglish');
    exit();
}

if(empty($LevelOfEducation||$LevelEducation)){
    header('location:index.php error=LevelOfEducation');
    exit();
}

if(empty($UploadPassport)){
    header('location:index.php error=UploadPassport');
    exit();
}

if(empty($OtherLangs)){
    header('location:index.php error=OtherLangs');
    exit();
}

if(empty($Disability)){
    header('location:index.php error=Disability');
    exit();
}

if(empty($ExplainDisability)){
    header('location:index.php error=ExplainDisability');
    exit();
}

if(empty($Religion)){
    header('location:index.php error=Religion');
    exit();
}
if(empty($SpecifyRelegion)){
    header('location:index.php error=SpecifyRelegion');
    exit();
}







if(empty($PA)){
    header('location:index.php error=PA');
    exit();
}

if(empty($PC)){
    header('location:index.php error=PC');
    exit();
}

if(empty($Town)){
    header('location:index.php error=Town');
    exit();
}

if(empty($YouCountry)){
    header('location:index.php error=YouCountry');
    exit();
}

if(empty($Telephone)){
    header('location:index.php error=Telephone');
    exit();
}
if(empty($MobileNo)){
    header('location:index.php error=MobileNo');
    exit();
}

if(empty($Course)){
    header('location:index.php error=Course');
    exit();
}







//load composer's autoloader
require 'vender/autoload.php';

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'bsclmr355721@gmail.com';                     //SMTP username
    $mail->Password   = 'Bsclmr@355721';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('bsclmr35572@gmail.com', 'ROBINSON');
    $mail->addAddress($email);     //Add a recipient


    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Successful Form Sumission ';

    $body = "
        Dear  $name <br/>
        Your Application has been submitted for : $Course<br/>
        Please await the outcome in two weeks time. <br />
        Yours Registrar
       
    ";


    $mail->Body    = $body ;
    $mail->AltBody = strip_tags($body);

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>